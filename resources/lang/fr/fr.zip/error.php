<?php 

return [
    'back' => 'Revenir',
    'back_to_home' => 'Retour au profil',
    'page' => [
        'not_found' => 'Page non trouvée',
    ],
    'permission' => 'L'utilisateur n'a pas la permission',
    'store_disabled' => 'store_disabled',
];